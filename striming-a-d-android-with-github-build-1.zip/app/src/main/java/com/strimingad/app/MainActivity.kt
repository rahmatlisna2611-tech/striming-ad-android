package com.strimingad.app

import android.os.Bundle
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF171B24)
private val Muted = Color(0xFF9AA4B5)
private val Accent = Color(0xFF8B5CF6)
private val Green = Color(0xFF20C997)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioApp() }
    }
}

@Composable
fun StudioApp() {
    var tab by remember { mutableStateOf("Studio") }
    var live by remember { mutableStateOf(false) }
    var mic by remember { mutableStateOf(true) }
    var camera by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf(setOf("YouTube", "TikTok")) }
    var server by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var avatarBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var mouthOpen by remember { mutableStateOf(false) }
    var avatarName by remember { mutableStateOf("Avatar PNG kamu") }
    val context = androidx.compose.ui.platform.LocalContext.current
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    avatarBitmap = BitmapFactory.decodeStream(stream)
                    avatarName = "Avatar berhasil dipilih"
                }
            } catch (_: Exception) {
                avatarName = "Gagal membaca gambar"
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    listOf("Studio", "Platforms", "PNG Tuber", "Overlay", "Chat", "Settings").forEach { item ->
                        val icon = when(item) {
                            "Studio" -> Icons.Default.Videocam
                            "Platforms" -> Icons.Default.Cast
                            "Overlay" -> Icons.Default.Layers
                            "PNG Tuber" -> Icons.Default.Face
                            "Chat" -> Icons.Default.Chat
                            else -> Icons.Default.Settings
                        }
                        NavigationBarItem(
                            selected = tab == item, onClick = { tab = item },
                            icon = { Icon(icon, null) },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = Color.White,
                                indicatorColor = Accent,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).background(Accent, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.GraphicEq, null, tint = Color.White)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("striming.a.d", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("MOBILE LIVE STUDIO", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).background(if(live) Color.Red else Green, CircleShape))
                        Spacer(Modifier.width(6.dp))
                        Text(if(live) "LIVE" else "READY", color = if(live) Color.Red else Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(20.dp))
                when(tab) {
                    "Studio" -> {
                        Text("Live control room", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(12.dp))
                        Box(Modifier.fillMaxWidth().height(230.dp).background(Color(0xFF202633), RoundedCornerShape(20.dp)).border(1.dp, Color(0xFF343B4A), RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Videocam, null, tint = Muted, modifier = Modifier.size(42.dp))
                                Spacer(Modifier.height(8.dp))
                                Text("Pratinjau kamera", fontWeight = FontWeight.SemiBold)
                                Text("Izin kamera diperlukan untuk menampilkan video", color = Muted, fontSize = 11.sp)
                            }
                            if(live) Surface(Modifier.align(Alignment.TopStart).padding(12.dp), color = Color.Red, shape = RoundedCornerShape(6.dp)) {
                                Text(" ● LIVE ", color = Color.White, modifier = Modifier.padding(6.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ToolCard("Kamera", if(camera) "Aktif" else "Mati", Icons.Default.Videocam, Modifier.weight(1f)) { camera = !camera }
                            ToolCard("Mikrofon", if(mic) "Aktif" else "Mute", Icons.Default.Mic, Modifier.weight(1f)) { mic = !mic }
                            ToolCard("Scene", "Utama", Icons.Default.Layers, Modifier.weight(1f)) { tab = "Overlay" }
                        }
                        Spacer(Modifier.height(18.dp))
                        Text("Tujuan siaran", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("TikTok", "YouTube", "Facebook").forEach { p ->
                                FilterChip(selected = selected.contains(p), onClick = {
                                    selected = if(selected.contains(p)) selected - p else selected + p
                                }, label = { Text(p) })
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Button(onClick = { live = !live }, modifier = Modifier.fillMaxWidth().height(54.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = if(live) Color(0xFF343B4A) else Color(0xFFE34252)),
                            shape = RoundedCornerShape(14.dp)) {
                            Icon(if(live) Icons.Default.Stop else Icons.Default.Radio, null)
                            Spacer(Modifier.width(8.dp))
                            Text(if(live) "HENTIKAN SIARAN" else "MULAI LIVE", fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Mode demo: tombol LIVE mengubah status antarmuka. Mesin encoder dan koneksi platform belum diaktifkan.", color = Muted, fontSize = 11.sp)
                    }
                    "Platforms" -> {
                        Text("Platform & RTMP", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Pilih tujuan dan masukkan alamat server dari akun streaming Anda.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(16.dp))
                        listOf("TikTok", "YouTube", "Facebook").forEach { p ->
                            CardRow(p, if(selected.contains(p)) "Dipilih untuk siaran" else "Belum dipilih", selected.contains(p)) {
                                selected = if(selected.contains(p)) selected - p else selected + p
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Text("RTMP khusus", fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(server, { server = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Server URL (rtmp/rtmps)") }, singleLine = true)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(key, { key = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Stream key") }, singleLine = true)
                        Text("Jangan bagikan stream key kepada siapa pun. Pada versi produksi, kunci harus disimpan terenkripsi.", color = Muted, fontSize = 11.sp)
                    }
                    "PNG Tuber" -> {
                        Text("PNG Tuber Studio", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Avatar transparan untuk menemani siaran kamu.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(14.dp))
                        Box(
                            Modifier.fillMaxWidth().height(290.dp)
                                .background(Color(0xFF202633), RoundedCornerShape(20.dp))
                                .border(1.dp, Color(0xFF343B4A), RoundedCornerShape(20.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (avatarBitmap != null) {
                                Image(
                                    bitmap = avatarBitmap!!.asImageBitmap(),
                                    contentDescription = "Avatar PNG Tuber",
                                    modifier = Modifier.fillMaxHeight().padding(12.dp),
                                    contentScale = ContentScale.Fit
                                )
                            } else {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Face, null, tint = Accent, modifier = Modifier.size(76.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text("Preview avatar PNG", fontWeight = FontWeight.SemiBold)
                                    Text("Pilih gambar PNG transparan untuk mulai", color = Muted, fontSize = 11.sp)
                                }
                            }
                            Surface(
                                Modifier.align(Alignment.TopEnd).padding(12.dp),
                                color = Accent, shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(if (mouthOpen) "MULUT TERBUKA" else "MULUT TERTUTUP",
                                    color = Color.White, modifier = Modifier.padding(7.dp), fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(avatarName, color = Muted, fontSize = 11.sp)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { avatarPicker.launch("image/png") }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.UploadFile, null)
                            Spacer(Modifier.width(8.dp))
                            Text("UPLOAD AVATAR PNG")
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { mouthOpen = !mouthOpen }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.GraphicEq, null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (mouthOpen) "Preview: mulut tertutup" else "Preview: mulut terbuka")
                        }
                        Spacer(Modifier.height(12.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Pengaturan avatar", fontWeight = FontWeight.SemiBold)
                                Text("Format: PNG transparan • Posisi: tengah • Layer: di atas kamera",
                                    color = Muted, fontSize = 11.sp)
                                Text("Catatan: animasi mulut otomatis berdasarkan level suara mikrofon dan pengaturan ukuran/posisi lanjutan akan diaktifkan pada tahap integrasi audio streaming.",
                                    color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                    "Overlay" -> {
                        Text("Scene & Overlay", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Atur elemen visual siaran.", color = Muted)
                        Spacer(Modifier.height(16.dp))
                        CardRow("Scene Utama", "Kamera + judul", true) {}
                        CardRow("Scene Gaming", "Screen capture + kamera kecil", false) {}
                        CardRow("Scene Istirahat", "Gambar / layar jeda", false) {}
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Tambah overlay (segera)") }
                    }
                    "Chat" -> {
                        Text("Live Chat", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(16.dp))
                        Box(Modifier.fillMaxWidth().height(250.dp).background(Panel, RoundedCornerShape(16.dp)).padding(16.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.ChatBubbleOutline, null, tint = Muted, modifier = Modifier.size(36.dp))
                                Text("Chat akan tampil saat konektor platform aktif", color = Muted, fontSize = 12.sp)
                            }
                        }
                    }
                    else -> {
                        Text("Pengaturan siaran", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(16.dp))
                        CardRow("Resolusi", "720p (default)", false) {}
                        CardRow("Frame rate", "30 FPS", false) {}
                        CardRow("Bitrate", "2500 Kbps", false) {}
                        CardRow("Orientasi", "Vertikal 9:16", false) {}
                        CardRow("Kamera", "Depan / Belakang", false) {}
                    }
                }
                Spacer(Modifier.height(24.dp))
                Text("striming.a.d • Versi 0.1.0 • Android", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun ToolCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Accent)
            Spacer(Modifier.height(5.dp))
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(value, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
fun CardRow(title: String, subtitle: String, enabled: Boolean, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).background(Color(0xFF29243B), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Cast, null, tint = Accent)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 11.sp)
            }
            if(enabled) Icon(Icons.Default.CheckCircle, null, tint = Green)
            else Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}
