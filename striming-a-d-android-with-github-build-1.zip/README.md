# striming.a.d — Android Live Studio (starter 0.1.0)

A native Android Studio starter project with a dark live-studio interface.

## Included
- Studio dashboard and live-status UI
- Platform selection UI (TikTok, YouTube, Facebook)
- Custom RTMP server/key fields
- PNG Tuber screen with PNG image import and manual mouth-state preview
- Scene/overlay and chat placeholder screens
- Camera/microphone control-state UI
- Android camera, microphone and internet permissions

## Important status
This is a **starter UI prototype**, not a finished streaming application. The LIVE button currently changes the demo interface state only. Camera preview, audio-reactive automatic mouth animation, avatar positioning/scaling, audio capture, RTMP encoding, multi-destination relay, platform chat APIs, OAuth/login, and secure credential storage still need implementation and testing.

For Android RTMP encoding, the open-source RootEncoder project is a possible engine:
https://github.com/pedroSG94/RootEncoder
Its README documents RTMP/RTMPS, RTSP, SRT and screen streaming. A multi-platform broadcast generally needs separate RTMP outputs or a relay server; platform access and stream-key availability depend on each account.

## Open and build
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Android Studio → Open → select the extracted `striming-ad` folder.
4. Allow Gradle sync and install Android SDK 35 if prompted.
5. Connect an Android phone with USB debugging enabled, then press Run.
6. To build an APK: Build → Build Bundle(s) / APK(s) → Build APK(s).

Package: `com.strimingad.app`
Minimum Android: 8.0 (API 26)

## Next development milestones
1. Add runtime permission handling and real CameraX preview.
2. Integrate RootEncoder for one RTMP destination.
3. Add background streaming service and screen capture with Android MediaProjection consent.
4. Add multiple RTMP outputs or a relay service.
5. Add platform-specific chat/login integrations where officially supported.
6. Encrypt stream keys and add robust reconnect/network handling.


## Build APK automatically with GitHub Actions
1. Create a new repository on GitHub, e.g. `striming-ad-android`.
2. Extract this ZIP.
3. Upload the contents of the extracted project folder to the repository root. Ensure `settings.gradle.kts`, `app/`, and `.github/` are at the root.
4. Open the repository's Actions tab and enable Actions if asked.
5. Select **Build Android APK** and tap **Run workflow**, or wait for the push build.
6. Open the completed run and download the `striming-a-d.apk` artifact.
7. Extract that downloaded artifact ZIP; it contains `app-debug.apk`. Install it on Android.

The debug APK is for manual testing, not Play Store release signing. The current project is a UI prototype; the actual camera/audio/RTMP streaming engine and multi-platform relay are not implemented yet.
